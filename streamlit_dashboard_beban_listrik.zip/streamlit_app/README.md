# ⚡ Dashboard Peramalan Beban Listrik Nasional Panama

Aplikasi Streamlit untuk:
1. **Menampilkan hasil semua model dari Kaggle**: klasik, ML, DL, dan transfer learning (Chronos, TimesFM, Moirai, Lag-Llama, TimeGPT).
2. **Ramalan langsung**: upload data beban terbaru (CSV/XLSX), lalu Chronos-Bolt meramal di CPU tanpa pelatihan ulang.

Desain evaluasi: pembagian kronologis **70% train : 10% validasi : 20% test** (1.402 : 200 : 400 hari),
dengan **rolling-origin harian**. Setiap pukul 00:00 model meramal 24 jam ke depan.

## Isi dashboard
| Tab | Isi |
|---|---|
| 🏠 Ringkasan | Insight otomatis, ramalan 24 jam + interval 80%, jam kritis (puncak, kenaikan tercepat, load factor, status), peringkat model, donut pengaruh variabel, MAPE normal vs COVID |
| 🏆 Evaluasi Model | Perbandingan MAPE/MAE/RMSE, galat per horizon, peta galat bulanan, cek kebocoran pretraining, hybrid vs peramal dasar, tabel lengkap |
| 📉 Aktual vs Prediksi | Grafik per jam dengan zoom, prediksi vs aktual, sebaran galat, MAPE per hari dalam seminggu, hari dengan galat terbesar |
| 🔍 Variabel Berpengaruh | Variabel pengoreksi foundation model (hybrid), permutation importance per kelompok, top fitur, efek suhu (SHAP), korelasi |
| 📈 Eksplorasi Data | Tren & COVID, pola musiman tahunan, heatmap hari × jam, pola hari kerja/libur, suhu vs beban, pembagian data |
| 🚀 Ramalan Langsung | Upload CSV/XLSX lalu ramal dengan Chronos-Bolt, dengan mode uji (backtest) |

Keluarga model: Baseline, Klasik, Machine Learning, Deep Learning, Transfer Learning, **Hybrid** (foundation model + model buatan sendiri), Ensemble.
Model transfer learning yang **dicurigai bocor** (sudah melihat data saat pretraining) diberi tanda ⚠️ dan tidak dipilih sebagai model terbaik.

Filter di bagian atas (model, kondisi normal/COVID, rentang tanggal uji) berlaku untuk tab Ringkasan, Evaluasi, dan Aktual vs Prediksi.

## Struktur folder

```
app.py
requirements.txt
.streamlit/config.toml      # tema terang
hasil_kaggle/               # hasil dari notebook Kaggle (ganti dengan milik Anda)
  meta.json
  leaderboard_model.csv
  prediksi_model.csv.gz
  data_historis.csv.gz
  ramalan_24jam_kedepan.csv
  pengaruh_fitur.csv
  pengaruh_kelompok.csv
  korelasi_eksogen.csv
  shap_sampel.csv.gz        # muncul jika SHAP tersedia di Kaggle
  cek_kebocoran.csv         # cek kebocoran data pretraining foundation model
  pengaruh_fitur_hybrid.csv # variabel yang mengoreksi foundation model (jika hybrid berjalan)
```

> Folder `hasil_kaggle/` bawaan hanyalah **contoh** dari model yang bisa dijalankan tanpa GPU.
> Ganti dengan hasil Anda sendiri dari Kaggle (langkah 1) supaya model transfer learning ikut tampil.

## Langkah 1: Ambil hasil dari Kaggle
1. Jalankan notebook `forecast_beban_listrik_panama.ipynb` sampai sel terakhir **[14] Ekspor hasil**.
2. Buka panel **Output** di Kaggle (`/kaggle/working/`) dan download **`hasil_kaggle.zip`**.
3. Ekstrak isinya ke folder `hasil_kaggle/` di repo ini, ganti file contoh yang ada.

## Langkah 2: Coba di komputer sendiri (opsional)
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Langkah 3: Deploy ke Streamlit Community Cloud
1. Buat repo GitHub baru, lalu upload semua isi folder ini, **termasuk folder `.streamlit/` dan `hasil_kaggle/`**.
2. Buka https://share.streamlit.io, login dengan GitHub, lalu klik **Create app**.
3. Pilih repo, branch `main`, dan main file `app.py`.
4. Di **Advanced settings**, pilih Python **3.11**, lalu klik **Deploy**.
5. Instalasi pertama butuh beberapa menit karena mengunduh torch CPU. Model Chronos-Bolt diunduh saat ramalan langsung pertama kali dijalankan.

Alternatif: **Hugging Face Spaces** (SDK: Streamlit), dengan file yang sama. Memorinya lebih besar sehingga
cocok untuk Chronos-Bolt Base.

## Tanpa deploy ulang
Hasil Kaggle versi baru juga bisa langsung di-upload sebagai `hasil_kaggle.zip` lewat sidebar aplikasi.

## Format data untuk Ramalan Langsung
File CSV/XLSX minimal punya kolom waktu dan kolom beban, contoh:

| datetime | nat_demand |
|---|---|
| 2020-06-26 01:00 | 1012.5 |
| 2020-06-26 02:00 | 978.1 |

- Kolom waktu dan target bisa dipilih di aplikasi.
- Interval data (per jam, per 30 menit, dll.) dideteksi otomatis.
- Data yang bolong diisi dengan interpolasi linier.
- **Mode uji (backtest)** menyembunyikan H data terakhir, lalu membandingkan ramalan dengan nilai aktual dan Seasonal Naive.

## Catatan
- Kalau instalasi torch/chronos gagal di server, tab Ramalan Langsung otomatis memakai Seasonal Naive sebagai cadangan.
  Tab lain tetap berjalan.
- Chronos-Bolt dilatih hingga 64 langkah ke depan. Horizon lebih panjang tetap bisa, tetapi akurasinya turun.
